import pygame
import pika
import uuid
import json
import sys
from threading import Thread

pygame.init()

screen = pygame.display.set_mode((800,600))
backdround = pygame.image.load("ground1.jpg")
Font1 = pygame.font.SysFont('Arial',10)
Font2 = pygame.font.SysFont('Arial',18)
font = pygame.font.SysFont('Arial',30)


IP = '34.254.177.17'
PORT = 5672
VIRTUAL_HOST = 'dar-tanks'
USER = 'dar-tanks'
PASSWORD = '5orPLExUYnyVYZg48caMpX'

class SingleRpcClient(object):

    def __init__(self):
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(
                host = IP,
                port = PORT,
                virtual_host = VIRTUAL_HOST,
                credentials=pika.PlainCredentials(
                    username = USER,
                    password = PASSWORD
                )
            )
        )
        self.channel = self.connection.channel()
        queue = self.channel.queue_declare(queue='',
                                           auto_delete=True,
                                           exclusive=True
                                           )
        self.callback_queue = queue.method.queue
        self.channel.queue_bind(
            exchange='X:routing.topic',
            queue = self.callback_queue
            )

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True
        )

        self.response = None
        self.corr_id = None
        self.token = None
        self.tank_id = None
        self.room_id = None

    def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = json.loads(body)
            print(self.response)
 

    def call(self, key, message={}):
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange='X:routing.topic',
            routing_key=key,
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
            ),
            body=json.dumps(message)
            )
        while self.response is None:
            self.connection.process_data_events()
       
    def check_server_status(self):
        self.call('tank.request.healthcheck')
        return self.response['status'] == '200'
    
    def obtain_token(self, room_id):
        
        message = {
            'roomId': room_id
        }
        self.call('tank.request.register', message)
        if 'token' in self.response:
            self.token = self.response['token']
            self.tank_id = self.response['tankId']
            if self.tank_id == client.tank_id:
                return 1
            else : return 0
            self.room_id = self.response['roomId']
            return True
        return False


    def turn_tank(self, token, direction):
        message = {
            'token': token,
            'direction': direction
        }
        self.call('tank.request.turn', message)

    def fire_bullet(self, token):
        message = {
            'token': token
        }
        self.call('tank.request.fire', message)
    
    

class MultiConsumerClient(Thread):
    def __init__(self, room_id):
        super().__init__()
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(
                host = IP,
                port = PORT,
                virtual_host = VIRTUAL_HOST,
                credentials=pika.PlainCredentials(
                    username = USER,
                    password = PASSWORD
                )
            )
        )
        self.channel = self.connection.channel()
        queue = self.channel.queue_declare(queue='',
                                           auto_delete=True,
                                           exclusive=True
                                           )

        event_listener = queue.method.queue
        self.channel.queue_bind(exchange='X:routing.topic', queue=event_listener, routing_key='event.state.'+room_id)

        self.channel.basic_consume(
            queue=event_listener,
            on_message_callback=self.on_response,
            auto_ack=True
        )
        self.response = None
    def on_response(self, ch, method, props, body):
        self.response = json.loads(body)
    def run(self):
        self.channel.start_consuming()

    def close(self):
        self.connection.close()

UP = 'UP'
DOWN = 'DOWN'
RIGHT = 'RIGHT'
LEFT = 'LEFT'



def d_tank(x, y, width, height, direction, id, health, score,):

    tank1 = pygame.image.load('t1_up.png') 
    tank2 = pygame.image.load('t2_up.png')

    if client.tank_id == id:
        if direction == LEFT: 
            tank1 = pygame.image.load('t1_left.png')
            screen.blit(tank1,(x,y))

        elif direction == RIGHT:
            tank1 = pygame.image.load('t1_right.png')
            screen.blit(tank1,(x,y))

        elif direction == UP:
            tank1 = pygame.image.load('t1_up.png')
            screen.blit(tank1,(x,y))

        elif direction == DOWN:
            tank1 = pygame.image.load('t1_down.png')
            screen.blit(tank1,(x,y))

        screen.blit(Font1.render(f"{id}",True,(0,0,0)),(x,y-int(width/2)))
    else:
        if direction == LEFT: 
            tank2 = pygame.image.load('t2_left.png')
            screen.blit(tank2,(x,y))

        elif direction == RIGHT:
            tank2 = pygame.image.load('t2_right.png')
            screen.blit(tank2,(x,y))

        elif direction == UP:
            tank2 = pygame.image.load('t2_up.png')
            screen.blit(tank2,(x,y))

        elif direction == DOWN:
            tank2 = pygame.image.load('t2_down.png')
            screen.blit(tank2,(x,y))

        screen.blit(Font1.render(f"{id}",True,(250,250,250)),(x,y-int(width/2)))

    screen.blit(Font2.render(f"HP:{health}",True,(250,250,250)),(10,10))
    screen.blit(Font2.render(f"score:{score}",True,(250,250,250)),(10,30))
    
def d_bullet(x, y, direction, id):
    if client.tank_id == id:
        if direction == UP:
            screen.blit(pygame.image.load("bullet_up.png"),(x,y))

        elif direction == DOWN:
            screen.blit(pygame.image.load("bullet_down.png"),(x,y))

        elif direction == RIGHT:
            screen.blit(pygame.image.load("bullet_right.png"),(x,y))

        elif direction == LEFT:
            screen.blit(pygame.image.load("bullet_left.png"),(x,y))
        
    else:
        if direction == UP:
            screen.blit(pygame.image.load("bullet1_up.png"),(x,y))

        elif direction == DOWN:
            screen.blit(pygame.image.load("bullet1_down.png"),(x,y))

        elif direction == RIGHT:
            screen.blit(pygame.image.load("bullet1_right.png"),(x,y))

        elif direction == LEFT:
            screen.blit(pygame.image.load("bullet1_left.png"),(x,y))

def multi_tank_winner(score):
    screen.blit(font.render('YOU WINNER', True, (255, 255, 255)), (200, 100))
    screen.blit(font.render('YOUR SCORE: {}'.format(score), True, (255, 255, 255)), (250, 400))

def multi_tank_loser(score):
    screen.blit(font.render('YOU LOSER', True, (255, 255, 255)), (200, 100))
    screen.blit(font.render('YOUR SCORE: {}'.format(score), True, (255, 255, 255)), (250, 400))

def multi_tank_kicked(score):
    screen.blit(font.render('YOU KICKED', True, (255, 255, 255)), (200, 100))
    screen.blit(font.render('YOUR SCORE: {}'.format(score), True, (255, 255, 255)), (250, 400))

def game():
    running = True
    score = 0
    while running:
        

        screen.blit(pygame.transform.scale(backdround,(800,600)),(0,0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key ==pygame.K_LEFT:
                    client.turn_tank(client.token,LEFT)
                if event.key ==pygame.K_RIGHT:
                    client.turn_tank(client.token,RIGHT)
                if event.key==pygame.K_UP:
                    client.turn_tank(client.token,UP)
                if event.key==pygame.K_DOWN:
                    client.turn_tank(client.token,DOWN)
                if event.key == pygame.K_SPACE:
                    client.fire_bullet(client.token)
                
        
        try:
            remaining_time = event_client.response['remainingTime']
            screen.blit(Font2.render(f"Remaining Time:{remaining_time}",True,(250,250,250)),(600,550))

            hits=event_client.response['hits']
            winners=event_client.response['winners']
            
            bullets = event_client.response['gameField']['bullets']

            for bullet in bullets:
                bullet_direction = bullet['direction']
                d_bullet(bullet['x'],bullet['y'],bullet_direction)
            
            tanks = event_client.response['gameField']['tanks']
            for tank in tanks :
                players.append(tank['id'])
                if tank['id']==client.tank_id:           
                    score=tank['score']
                    window.blit(Font2.render('{0}: |hp: {1}, |score: {2}'.format(tank['id'],tank['health'],tank['score']),True,(21,255,21)),(840,100+(20*i)))
                else:
                    window.blit(Font4.render('{0}: |hp: {1}, |score: {2}'.format(tank['id'],tank['health'],tank['score']),True,(255,21,21)),(840,100+(20*i)))
                    d_tank(**tank)
                    
            if win == True:
                multi_tank_winner(score)

            if lose == True:
                multi_tank_loser(score)

            if kick == True:
                kicked_tank(score)

        except:
            pass

        pygame.display.update()
    client.connection.close()
    pygame.quit()
    sys.exit()

client = SingleRpcClient()
client.check_server_status()
client.obtain_token('room-19')
event_client = MultiConsumerClient('room-19')
event_client.start()
game()