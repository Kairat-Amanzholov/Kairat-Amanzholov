import pygame
import random
import math
import sys

pygame.init()

myfont = pygame.font.SysFont('arial', 40)

w = 800
h = 600

screen = pygame.display.set_mode((w, h))

FPS = 60

clock = pygame.time.Clock() 

tank1 = pygame.image.load('t1_up.png') 
tank2 = pygame.image.load('t2_up.png') 

arrow_1 = pygame.Surface((10,10))
arrow_2 = pygame.Surface((10,10))

menu_bg = pygame.image.load('bg.png')

arrow1_x = 1200
arrow1_y = 1200
shoot1 = False
arrow2_x = 1200
arrow2_y = 1200
shoot2 = False

x_tank1 = 100
y_tank1 = 300

x_tank2 = 600
y_tank2 = 300

life1 = 3
life2 = 3

music=pygame.mixer.music.load('bg_sound.mp3')
tank_sound=pygame.mixer.Sound('tank_sound3.wav')
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.5)

speed = 4
t = 0
t2 = 95
z = 0
p = 0

UP = 'UP'
DOWN = 'DOWN'
LEFT = 'LEFT'
RIGHT = 'RIGHT'

movement1 = False 
movement2 = False 

wall1 = True
wall2 = True
wall3 = True

power = False
power_force = False
power_force2 = False

single = True


pygame.display.update()

class Menu:
	def __init__(self, punkts = [120, 140 ,u'Punkt', (250,250,30), (250,30,250)]):
		self.punkts = punkts
	def render(self, poverhnost, font, num_punkt):
		for i in self.punkts:
			if num_punkt == i[5]:
				poverhnost.blit(font.render(i[2], 1, i[4]), (i[0], i[1]))
			else:
				poverhnost.blit(font.render(i[2], 1, i[3]), (i[0], i[1]))


	def menu(self):
		done = True
		font_menu = pygame.font.SysFont('arial', 50)
		punkt = 0
		while done:
			menu_bg = pygame.image.load('bg.png')
			screen.blit(menu_bg,(0,0))
            
			mp = pygame.mouse.get_pos()
			for i in self.punkts:
				if mp[0]>i[0] and mp[0]<i[0]+155 and mp[1]>i[1] and mp[1]<i[1]+50:
					punkt =i[5]
			self.render(screen, font_menu, punkt)

			for e in pygame.event.get():
				if e.type == pygame.QUIT:
					sys.exit()
				if e.type == pygame.KEYDOWN:
					if e.key == pygame.K_ESCAPE:
						sys.exit()
					if e.key == pygame.K_UP:
						if punkt > 0:
							punkt -= 1
					if e.key == pygame.K_DOWN:
						if punkt < len(self.punkts)-1:
							punkt += 1
				if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
					if punkt == 0:
						done = False

					elif punkt == 1:
						done = False

					elif punkt == 2:
						bot = true
					
					elif punkt == 3:
						sys.exit()

			pygame.display.flip()

def end(last_thene1, last_thene2):
	myfont = pygame.font.SysFont('arial', 100)
	ending1 = myfont.render('GAME OVER', True, (255,255,255))
	ending1_1 = myfont.render('P1 wins', True, (255,255,255))
	ending2 = myfont.render('GAME OVER', True, (255,255,255))
	ending1_2 = myfont.render('P2 wins', True, (255,255,255))

	if last_thene1 == 0:
		background = pygame.display.set_mode((w,h))
		background.fill((0,0,0))
		screen.blit(background,(0,0))
		screen.blit(ending2,(300, 200))
		screen.blit(ending1_2,(400, 300))
		
	if last_thene2 == 0:
		background = pygame.display.set_mode((w,h))
		background.fill((0,0,0))
		screen.blit(background,(0,0))
		screen.blit(ending1,(300, 200))
		screen.blit(ending1_1,(400, 300))

def hit1(arrow_x, arrow_y, x_tank, y_tank):
	if arrow_x >= x_tank and arrow_x <= x_tank + 31 and arrow_y >= y_tank and arrow_y <= y_tank + 31:
		return True
	else: return False

def hit2(arrow_x, arrow_y, x_tank, y_tank):
	if arrow_x >= x_tank and arrow_x <= x_tank + 31 and arrow_y >= y_tank and arrow_y <= y_tank + 31:
		return True
	else: return False

def hit3(x_tank, y_tank, x, y):
	if  x_tank + 31 >= x and x_tank <= x + 20 and y_tank + 31 >= y and y_tank <= y + 20:
		return True
	else: return False

def hit4(x_tank, y_tank, x, y):
	if  x_tank + 31 >= x and x_tank <= x + 20 and y_tank + 31 >= y and y_tank <= y + 20:
		return True
	else: return False

def wallif(x, y, x1, y1, x_tank, y_tank, x1_tank, y1_tank):
	if (x + 20 < x1 or x > x1 + 20 or y + 20 < y1 or y > y1 + 20) and (x + 20 < x_tank or x > x_tank + 31 or y + 20 < y_tank or y > y_tank + 31) and (x + 20 < x1_tank or x > x1_tank + 31 or y + 20 < y1_tank or y > y1_tank + 31):
		return True
	else: return False

def wallif1(x, y, x1, y1, x2, y2, x_tank, y_tank, x1_tank, y1_tank):
	if (x + 20 < x1 or x > x1 + 20 or y + 20 < y1 or y > y1 + 20) and (x + 20 < x2 or x > x2 + 20 or y + 20 < y2 or y > y2 + 20) and (x + 20 < x_tank or x > x_tank + 31 or y + 20 < y_tank or y > y_tank + 31) and (x + 20 < x1_tank or x > x1_tank + 31 or y + 20 < y1_tank or y > y1_tank + 31):
		return True
	else: return False


x = random.randrange(90, 720, 20)
y = random.randrange(140, 480, 20)
x1 = random.randrange(90, 720, 20)
y1 = random.randrange(140, 480, 20)
x2 = random.randrange(90, 720, 20)
y2 = random.randrange(140, 480, 20)

time = random.randrange(1,500)


play = True
	
punkts = [(300, 140, u'Single Game', (250,250,30), (250,30,250), 0),
          (300, 210, u'Multi Game', (250,250,30), (250,30,250), 1),
		  (300, 280, u'Multi By Bot', (250,250,30), (250,30,250), 2),
		  (300, 350, u'Quit', (250,250,30), (250,30,250), 3)]
game = Menu(punkts)
game.menu()

if single == True:
	while play:

		milliseconds = clock.tick(FPS) 
		seconds = milliseconds/1000
		t += math.ceil(seconds)

		pygame.time.delay(30)
	
		screen.fill((0,0,0))
		pygame.display.update()	

		arrow_1.fill((255,255,0))
		arrow_2.fill((255,255,0))
	
		if power == False and power_force == False and power_force2 == False and (z < 95 and p < 95):
			if t > time:
				power = True

		if power :
			power_x = 400
			power_y = 50
			pygame.draw.rect(screen, (255,255,255),(power_x,power_y,20,20))

		if wall1:
			pygame.draw.rect(screen, (255,0,0),(x,y,20,20))

		if wall2:
			if wallif(x1 , y1, x, y, 100, 300, 600, 300):
				pygame.draw.rect(screen, (255,0,0),(x1,y1,20,20))

		if wall2:
			if (wallif(x1 , y1, x, y, 100, 300, 600, 300) == False) and ((x1 + 20 < 100) or (x1 > 100 + 31) or (y1 + 20 < 300) or (y1 > 300 + 31)) and ((x1 + 20 < 600) or (x1 > 600 + 31) or (y1 + 20 < 300) or (y1 > 300 + 31)):
				pygame.draw.rect(screen, (255,0,0),(x1,y1,20 ,20))

		if wall3:
			if wallif1(x2, y2, x, y, x1, y1, 100, 300, 600, 300) and  wallif(x1 , y1, x, y, 100, 300, 600, 300):
				pygame.draw.rect(screen, (255,0,0),(x2,y2,20,20))


		keys = pygame.key.get_pressed()
		if power_force == False:
			if movement1 == UP:
				tank1 = pygame.image.load('t1_up.png') 
				y_tank1 -= speed*seconds*60
				if shoot1:
					arrow1_y -= 20
					if arrow1_y < -10:
						shoot1 = False

			if movement1 == DOWN:
				tank1 = pygame.image.load('t1_down.png')
				y_tank1 += speed*seconds*60
				if shoot1:
					arrow1_y += 20
					if arrow1_y > h + 10:
						shoot1 = False

			if movement1 == RIGHT:
				tank1 = pygame.image.load('t1_right.png')
				x_tank1 += speed*seconds*60
				if shoot1:
					arrow1_x += 20
					if arrow1_x > w + 10:
						shoot1 = False

			if movement1 == LEFT:
				tank1 = pygame.image.load('t1_left.png')
				x_tank1 -= speed*seconds*60
				if shoot1:
					arrow1_x -= 20
					if arrow1_x < -10:
						shoot1 = False

		if power_force2 == False:
			if movement2 == UP:
				tank2 = pygame.image.load('t2_up.png')
				y_tank2 -= speed*seconds*60
				if shoot2:
					arrow2_y -= 20
					if arrow2_y < -10:
						shoot2 = False

			if movement2 == DOWN:
				tank2 = pygame.image.load('t2_down.png')
				y_tank2 += speed*seconds*60
				if shoot2:
					arrow2_y += 20
					if arrow2_y > h + 10:
						shoot2 = False

			if movement2 == RIGHT:
				tank2 = pygame.image.load('t2_right.png')
				x_tank2 += speed*seconds*60
				if shoot2:
					arrow2_x += 20
					if arrow2_x > w + 10:
						shoot2 = False

			if movement2 == LEFT:
				tank2 = pygame.image.load('t2_left.png')
				x_tank2 -= speed*seconds*60
				if shoot2:
					arrow2_x -= 20
					if arrow2_x < -10:
						shoot2 = False
	

		if hit1(arrow1_x, arrow1_y, x_tank2, y_tank2):
			life2 = life2 - 1
			shoot1 = False
			pygame.mixer.Sound.play(tank_sound)
			arrow1_x = 1200
			arrow1_y = 1200
			x_tank2 = 600
			y_tank2 = 300

		if (arrow1_x >= x and arrow1_x <= x + 20 and arrow1_y >= y and arrow1_y <= y + 20):
			wall1 = False
			shoot1 = False
			arrow1_x = 1200
			arrow1_y = 1200
	
		if (arrow2_x >= x and arrow2_x <= x + 20 and arrow2_y >= y and arrow2_y <= y + 20):
			wall1 = False
			shoot2 = False
			arrow2_x = 1200
			arrow2_y = 1200

		if (arrow1_x >= x1 and arrow1_x <= x1 + 20 and arrow1_y >= y1 and arrow1_y <= y1 + 20):
			wall2 = False
			shoot1 = False
			arrow1_x = 1200
			arrow1_y = 1200

		if (arrow2_x >= x1 and arrow2_x <= x1 + 20 and arrow2_y >= y1 and arrow2_y <= y1 + 20):
			wall2 = False
			shoot2 = False
			arrow2_x = 1200
			arrow2_y = 1200

		if (arrow1_x >= x2 and arrow1_x <= x2 + 20 and arrow1_y >= y2 and arrow1_y <= y2 + 20):
			wall3 = False
			shoot1 = False
			arrow1_x = 1200
			arrow1_y = 1200

		if  (arrow2_x >= x2 and arrow2_x <= x2 + 20 and arrow2_y >= y2 and arrow2_y <= y2 + 20):
			wall3 = False
			shoot2 = False
			arrow2_x = 1200
			arrow2_y = 1200

		if  hit2(arrow2_x, arrow2_y, x_tank1, y_tank1):
			life1 = life1 - 1
			shoot2 = False
			pygame.mixer.Sound.play(tank_sound)
			arrow2_x = 1200
			arrow2_y = 1200
			x_tank1 = 100
			y_tank1 = 300

		if power:
			if (x_tank1 + 31 >= power_x and x_tank1 <= power_x + 20 and y_tank1 + 31 >= power_y and y_tank1 <= power_y + 20) and power:
				power = False
				power_force = True

		if power_force :
			z +=  math.ceil(seconds)
			if movement1 == UP:
				tank1 = pygame.image.load('t1_up.png') 
				y_tank1 -= speed*seconds*60*2
				if shoot1:
					arrow1_y -= 40
					if arrow1_y < -10:
						shoot1 = False

			if movement1 == DOWN:
				tank1 = pygame.image.load('t1_down.png')
				y_tank1 += speed*seconds*60*2
				if shoot1:
					arrow1_y += 40
					if arrow1_y > h + 10:
						shoot1 = False

			if movement1 == RIGHT:
				tank1 = pygame.image.load('t1_right.png')
				x_tank1 += speed*seconds*60*2
				if shoot1:
					arrow1_x += 40
					if arrow1_x > w + 10:
						shoot1 = False

			if movement1 == LEFT:
				tank1 = pygame.image.load('t1_left.png')
				x_tank1 -= speed*seconds*60*2
				if shoot1:
					arrow1_x -= 40
					if arrow1_x < -10:
						shoot1 = False
		if z > 95:
			power_force = False
	
		if power:
			if (x_tank2 + 31 >= power_x and x_tank2 <= power_x + 20 and y_tank2 + 31 >= power_y and y_tank2 <= power_y + 20) :
				power = False
				power_force2 = True

		if power_force2 :
			p +=  math.ceil(seconds)
			if movement2 == UP:
				tank2 = pygame.image.load('t2_up.png')
				y_tank2 -= speed*seconds*60*2
				if shoot2:
					arrow2_y -= 40
					if arrow2_y < -10:
						shoot2 = False

			if movement2 == DOWN:
				tank2 = pygame.image.load('t2_down.png')
				y_tank2 += speed*seconds*60*2
				if shoot2:
					arrow2_y += 40
					if arrow2_y > h + 10:
						shoot2 = False

			if movement2 == RIGHT:
				tank2 = pygame.image.load('t2_right.png')
				x_tank2 += speed*seconds*60*2
				if shoot2:
					arrow2_x += 40
					if arrow2_x > w + 10:
						shoot2 = False

			if movement2 == LEFT:
				tank2 = pygame.image.load('t2_left.png')
				x_tank2 -= speed*seconds*60*2
				if shoot2:
					arrow2_x -= 40
					if arrow2_x < -10:
						shoot2 = False

		if p > 95:
			power_force2 = False

		if wall1:	
			if  hit3(x_tank1, y_tank1, x, y):
				life1 = life1 - 1
				wall1 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank1 = 100
				y_tank1 = 300

		if wall2:
			if  hit3(x_tank1, y_tank1, x1, y1):
				life1 = life1 - 1
				wall2 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank1 = 100
				y_tank1 = 300
	
		if wall3:
			if  hit3(x_tank1, y_tank1, x2, y2):
				life1 = life1 - 1
				wall3 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank1 = 100
				y_tank1 = 300

		if wall1:
			if  hit4(x_tank2, y_tank2, x, y):
				life2 = life2 - 1
				wall1 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank2 = 600
				y_tank2 = 300

		if wall2:
			if  hit4(x_tank2, y_tank2, x1, y1):
				life2 = life2 - 1
				wall2 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank2 = 600
				y_tank2 = 300
	
		if wall3:
			if  hit4(x_tank2, y_tank2, x2, y2):
				life2 = life2 - 1
				wall3 = False
				pygame.mixer.Sound.play(tank_sound)
				x_tank2 = 600
				y_tank2 = 300

		if x_tank1 > w + 60:
			x_tank1 = -60

		if x_tank1 < -60:
			x_tank1 = w + 60

		if y_tank1 > h + 60:
			y_tank1 = -60
	
		if y_tank1 < -60:
			y_tank1 = h + 60
                                             
		if x_tank2 > w + 60:
			x_tank2 = -60
	
		if x_tank2 < -60:
			x_tank2 = w + 60
	
		if y_tank2 > h + 60:
			y_tank2 = -60
	
		if y_tank2 < -60:
			y_tank2 = h + 60

		for event in pygame.event.get():

			if event.type == pygame.QUIT:
				play = False

			if event.type == pygame.KEYDOWN:

				if event.key == pygame.K_ESCAPE:
					exit()

				if event.key == pygame.K_SPACE:
					pygame.mixer.Sound.play(tank_sound)

					if shoot1 == False:
						shoot1 = True

						if movement1 == UP:
							arrow1_x = x_tank1 + 14
							arrow1_y = y_tank1

						if movement1 == DOWN:
							arrow1_x = x_tank1 + 14
							arrow1_y = y_tank1 + 31

						if movement1 == RIGHT:
							arrow1_x = x_tank1 + 31
							arrow1_y = y_tank1 + 14

						if movement1 == LEFT:
							arrow1_x = x_tank1 
							arrow1_y = y_tank1 + 14

				
				if event.key == pygame.K_RETURN:
					pygame.mixer.Sound.play(tank_sound)

					if shoot2 == False:
						shoot2 = True

						if movement2 == UP:
							arrow2_x = x_tank2 + 14
							arrow2_y = y_tank2

						if movement2 == DOWN:
							arrow2_x = x_tank2 + 14
							arrow2_y = y_tank2 + 31

						if movement2 == RIGHT:
							arrow2_x = x_tank2 + 31
							arrow2_y = y_tank2 + 14

						if movement2 == LEFT:
							arrow2_x = x_tank2 
							arrow2_y = y_tank2 + 14

				if event.key == pygame.K_d:  
					movement1 = RIGHT

				if event.key == pygame.K_a:
					movement1 = LEFT

				if event.key == pygame.K_w: 	
					movement1 = UP

				if event.key == pygame.K_s:
					movement1 = DOWN

				if event.key == pygame.K_RIGHT:
					movement2 = RIGHT

				if event.key == pygame.K_LEFT:
					movement2 = LEFT

				if event.key == pygame.K_UP:
					movement2 = UP
				
				if event.key == pygame.K_DOWN:
					movement2 = DOWN


		string1 = myfont.render("Player1:" , True, (255,255,255))
		string2 = myfont.render("Player2:" , True, (255,255,255))
	
		if life1 == 3:
			HP3 = pygame.image.load('HP3.png')
			screen.blit(HP3,(120,50))

		if life1 == 2:
			HP3 = pygame.image.load('HP2.png')
			screen.blit(HP3,(120,50))

		if life1 == 1:
			HP3 = pygame.image.load('HP1.png')
			screen.blit(HP3,(120,50))

		if life2 == 3:
			HP3 = pygame.image.load('HP3.png')
			screen.blit(HP3,(680,50))

		if life2 == 2:
			HP3 = pygame.image.load('HP2.png')
			screen.blit(HP3,(680,50))

		if life2 == 1:
			HP3 = pygame.image.load('HP1.png')
			screen.blit(HP3,(680,50))
	
    
	
		screen.blit(string1, (10, 50))
		screen.blit(string2, (550, 50))
		screen.blit(tank1, (x_tank1, y_tank1))
		screen.blit(tank2, (x_tank2, y_tank2))
	
		clock.tick(FPS)
	
		screen.blit(arrow_1, (arrow1_x,arrow1_y))
		screen.blit(arrow_2, (arrow2_x,arrow2_y))

		end(life1,life2)
		pygame.display.flip()

#------------------------------------------------------------------------------------------------------------------------------

punkts = [(300, 140, u'Single Game', (250,250,30), (250,30,250), 0),
          (300, 210, u'Multi Game', (250,250,30), (250,30,250), 1),
		  (300, 280, u'Multi By Bot', (250,250,30), (250,30,250), 2),
		  (300, 350, u'Quit', (250,250,30), (250,30,250), 3)]
game = Menu(punkts)
game.menu()











pygame.quit()